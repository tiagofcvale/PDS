public class PizzaMain {
    public static void main(String[] args) {
        Waiter waiter = new Waiter();
        IBuilder pizzaBuilder = new PizzaBuilder();

        waiter.setPizzaBuilder(pizzaBuilder);

        waiter.createPizza();

        Pizza pizza = waiter.getPizza();

        System.out.println(pizza);
    }
}
