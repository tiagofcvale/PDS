public class Waiter {
    
    protected IBuilder builder;

    public Waiter() {};

    public void setPizzaBuilder(IBuilder pizza) {
        this.builder = pizza;
    }

    public void createPizza() {
        this.builder.createPizza();
        this.builder.setPizzaDough();
        this.builder.setPizzaSauce();
        this.builder.setPizzaTopping();
    }

    public Pizza getPizza() {
        return this.builder.getPizza();
    }
}
