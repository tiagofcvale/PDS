public class Pizza {
    private String dough;
    private String sauce;
    private String topping;

    public Pizza() {}

    public void setDough(String dough) {
        this.dough = dough;
    }

    public String getDough() {
        return this.dough;
    }

    public void setSauce(String sauce) {
        this.sauce = sauce;
    }

    public String getSauce() {
        return this.sauce;
    }

    public void setTopping(String topping) {
        this.topping = topping;
    }

    public String getTopping() {
        return this.topping;
    }

    @Override
    public String toString() {
        return "Pizza with " + getDough() + " dough; " + getSauce() + " sauce; And " + getTopping() + " topping.";
    }
}
