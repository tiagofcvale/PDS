public interface IBuilder {
    public void setPizzaTopping();
    public void setPizzaSauce();
    public void setPizzaDough();
    public Pizza getPizza();
    public void createPizza();
}
