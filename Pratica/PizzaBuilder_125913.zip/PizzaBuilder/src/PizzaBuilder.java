public class PizzaBuilder implements IBuilder {

    protected Pizza pizza;

    @Override
    public void createPizza() {
        this.pizza = new Pizza();
    }

    @Override
    public Pizza getPizza() {
        return this.pizza;
    }

    @Override
    public void setPizzaTopping() {
        this.pizza.setTopping("Pepperoni");
    }

    @Override
    public void setPizzaSauce() {
        this.pizza.setSauce("Tomate");
    }

    @Override
    public void setPizzaDough() {
        this.pizza.setDough("Napolitana");
    }
}
