public interface OperationI {
    public int execute(int num1, int num2);
}