public interface Mediator {
    public void notify(Colleague colleague, String message);
}
