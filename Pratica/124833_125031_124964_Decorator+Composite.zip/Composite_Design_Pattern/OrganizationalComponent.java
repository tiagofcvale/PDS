public interface OrganizationalComponent {
    public void showDetails(String prefix);
}

