
Compilar - javac -d bin src/*.java

Correr por omissão (X) - java -cp bin Lab03.JogoGalo.src.JGalo
Correr com primeira jogada X - java -cp bin Lab03.JogoGalo.src.JGalo X
Correr com primeira jogada O - java -cp bin Lab03.JogoGalo.src.JGalo O


            